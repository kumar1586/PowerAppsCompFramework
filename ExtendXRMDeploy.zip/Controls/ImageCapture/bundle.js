var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./ImageCapture/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./ImageCapture/index.ts":
/*!*******************************!*\
  !*** ./ImageCapture/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar ImageCapture =\n/** @class */\nfunction () {\n  function ImageCapture() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  ImageCapture.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    debugger; // assigning environment variables.\n\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container; // register eventhandler functions\n\n    this._LoadPhotoContainer = this.LoadPhotoContainer.bind(this);\n    this._HidePhotoContainer = this.HidePhotoContainer.bind(this);\n    this._TakePhotoClicked = this.TakePhotoClicked.bind(this);\n    this._RetakePhotoClicked = this.RetakePhotoClicked.bind(this); //Load container\n\n    this._LoadControlElement = document.createElement(\"input\");\n\n    this._LoadControlElement.setAttribute(\"type\", \"button\");\n\n    this._LoadControlElement.setAttribute(\"value\", \"Load Video\");\n\n    this._LoadControlElement.setAttribute(\"style\", \"width:10%;color:white;background-color:#2e82e0;font-size:15px;padding:5px;margin:10px;border-color:black;border-style:double;\");\n\n    this._LoadControlElement.addEventListener(\"click\", this._LoadPhotoContainer); //Hide container\n\n\n    this._HideVideoButton = document.createElement(\"input\");\n\n    this._HideVideoButton.setAttribute(\"type\", \"button\");\n\n    this._HideVideoButton.setAttribute(\"value\", \"Hide Video\");\n\n    this._HideVideoButton.setAttribute(\"style\", \"width:10%;color:white;background-color:#2e82e0;font-size:15px;padding:5px;margin:10px;border-color:black;border-style:double;\");\n\n    this._HideVideoButton.addEventListener(\"click\", this._HidePhotoContainer); //Div\n\n\n    this._AppDiv = document.createElement(\"div\");\n\n    this._AppDiv.classList.add(\"app\"); // <a href=\"#\" id=\"start-camera\" class=\"visible\">Touch here to start the app.</a>\n\n\n    this._StartCameraAnchor = document.createElement(\"a\");\n\n    this._StartCameraAnchor.setAttribute(\"href\", \"#\"); //this._StartCameraAnchor.classList.add(\"visible\");\n\n\n    this._StartCameraAnchor.setAttribute(\"id\", \"start-camera\");\n\n    this._StartCameraAnchor.setAttribute(\"text\", \"Start your app here\"); //<video id=\"camera-stream\"> </video>\n\n\n    this._VideoCameraStream = document.createElement(\"video\");\n\n    this._VideoCameraStream.setAttribute(\"id\", \"camera-stream\"); //<img id=\"snap\" >\n\n\n    this._SnapImage = document.createElement(\"img\");\n\n    this._SnapImage.setAttribute(\"id\", \"snap\"); //<p id=\"error-message\"></p>\n\n\n    this._ErrorMessage = document.createElement(\"p\");\n\n    this._ErrorMessage.setAttribute(\"id\", \"error-message\"); //<canvas></canvas>\n\n\n    this._Canvas = document.createElement(\"canvas\");\n\n    this._AppDiv.appendChild(this._StartCameraAnchor);\n\n    this._AppDiv.appendChild(this._VideoCameraStream);\n\n    this._AppDiv.appendChild(this._SnapImage);\n\n    this._AppDiv.appendChild(this._ErrorMessage);\n\n    this._AppDiv.appendChild(this._Canvas); ////Take Photo Button        \n\n\n    this._TakePhotoButton = document.createElement(\"input\");\n\n    this._TakePhotoButton.setAttribute(\"type\", \"button\");\n\n    this._TakePhotoButton.setAttribute(\"value\", \"Take Snapshot\");\n\n    this._TakePhotoButton.setAttribute(\"style\", \"width:12%;color:white;background-color:#2e82e0;font-size:15px;padding:5px;margin:10px;border-color:black;border-style:double;\");\n\n    this._TakePhotoButton.addEventListener(\"click\", this._TakePhotoClicked); ////ReTake Photo Button        \n\n\n    this._RetakeVideoButton = document.createElement(\"input\");\n\n    this._RetakeVideoButton.setAttribute(\"type\", \"button\");\n\n    this._RetakeVideoButton.setAttribute(\"value\", \"ReTake Snapshot\");\n\n    this._RetakeVideoButton.setAttribute(\"style\", \"width:14%;color:white;background-color:#2e82e0;font-size:15px;padding:5px;margin:10px;border-color:black;border-style:double;\");\n\n    this._RetakeVideoButton.addEventListener(\"click\", this._RetakePhotoClicked); // finally add to the container so that it renders on the UI.\n\n\n    this._container.appendChild(this._AppDiv);\n\n    this._container.appendChild(this._LoadControlElement);\n\n    this._container.appendChild(this._TakePhotoButton);\n\n    this._container.appendChild(this._HideVideoButton);\n\n    this._container.appendChild(this._RetakeVideoButton); //\n\n\n    this.HideUI();\n  }; //Methods\n\n\n  ImageCapture.prototype.HideUI = function () {\n    this._StartCameraAnchor.classList.remove(\"visible\");\n\n    this._VideoCameraStream.classList.remove(\"visible\");\n\n    this._SnapImage.classList.remove(\"visible\");\n\n    this._ErrorMessage.classList.remove(\"visible\");\n\n    this._HideVideoButton.classList.remove(\"visible\");\n\n    this._TakePhotoButton.classList.remove(\"visible\");\n\n    this._RetakeVideoButton.classList.remove(\"visible\");\n  };\n\n  ImageCapture.prototype.showVideo = function () {\n    this.HideUI();\n\n    this._VideoCameraStream.classList.add(\"visible\");\n\n    this._HideVideoButton.classList.add(\"visible\");\n\n    this._TakePhotoButton.classList.add(\"visible\");\n\n    this._RetakeVideoButton.classList.add(\"visible\");\n  };\n\n  ImageCapture.prototype.takeSnapshot = function () {\n    // Here we're using a trick that involves a hidden canvas element.  \n    debugger;\n\n    var canvascontext = this._Canvas.getContext(\"2d\");\n\n    var width = this._VideoCameraStream.videoWidth;\n    var height = this._VideoCameraStream.videoHeight;\n\n    if (width && height) {\n      // Setup a canvas with the same dimensions as the video.\n      this._Canvas.width = width;\n      this._Canvas.height = height; // Make a copy of the current frame in the video on the canvas.\n      // @ts-ignore\n\n      canvascontext.drawImage(this._VideoCameraStream, 0, 0, width, height); // Turn the canvas image into a dataURL that can be used as a src for our photo.\n\n      this._canvasDataURL = this._Canvas.toDataURL('image/png');\n    }\n  };\n\n  ImageCapture.prototype.displayErrorMessage = function (strMsg) {\n    this.HideUI();\n\n    this._ErrorMessage.setAttribute(\"innerText\", strMsg);\n\n    this._ErrorMessage.classList.add(\"visible\");\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  ImageCapture.prototype.updateView = function (context) {\n    // Add code to update control view  \n    // @ts-ignore\n    var crmScreenshotOutcome = this._context.parameters.ImageSnapshot.attributes.LogicalName; // setting CRM field values here.\n    // @ts-ignore\n\n    Xrm.Page.getAttribute(crmScreenshotOutcome).setValue(this._context.parameters.ImageSnapshot.formatted); //If Image already available then set it to field.\n    // @ts-ignore\n\n    var crmScreenshotIntialOutcome = this._context.parameters.ImageSnapshot.attributes.LogicalName; // @ts-ignore\n\n    var strInitialOutcome = Xrm.Page.getAttribute(crmScreenshotIntialOutcome).getValue();\n\n    if (strInitialOutcome != null && strInitialOutcome != undefined && strInitialOutcome != \"\") {\n      var snap = strInitialOutcome; // Show image.        \n\n      this._SnapImage.setAttribute('src', snap);\n\n      this._SnapImage.classList.add(\"visible\");\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  ImageCapture.prototype.getOutputs = function () {\n    return {\n      ImageSnapshot: this._canvasDataURL\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  ImageCapture.prototype.destroy = function () {// Add code to cleanup control if necessary\n  }; // event handlers\n\n\n  ImageCapture.prototype.LoadPhotoContainer = function (evt) {\n    debugger;\n    var self = this;\n    var getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia;\n\n    if (!getUserMedia) {\n      this.displayErrorMessage(\"Your browser doesn't have support for the navigator.getUserMedia interface.\");\n    } else {\n      // Request the camera.\n      navigator.mozGetUserMedia({\n        video: true\n      }, function (stream) {\n        debugger;\n        self._VideoCameraStream.src = window.URL.createObjectURL(stream);\n\n        self._VideoCameraStream.play();\n\n        self._VideoCameraStream.onplay = function () {\n          debugger;\n          self.showVideo();\n        };\n      }, // Error Callback\n      function (err) {\n        self.displayErrorMessage(\"There was an error with accessing the camera stream: \" + err.name);\n      });\n    } // this will call the getOutputs method.\n\n\n    this._notifyOutputChanged();\n  };\n\n  ImageCapture.prototype.TakePhotoClicked = function (evt) {\n    debugger;\n    this.takeSnapshot();\n    var snap = this._canvasDataURL; // Show image.        \n\n    this._SnapImage.setAttribute('src', snap);\n\n    this._SnapImage.classList.add(\"visible\"); // Pause video playback of stream.\n\n\n    this._VideoCameraStream.pause();\n\n    this._notifyOutputChanged();\n  };\n\n  ImageCapture.prototype.RetakePhotoClicked = function (evt) {\n    debugger; // Hide image.        \n\n    this._SnapImage.setAttribute('src', '');\n\n    this._SnapImage.classList.remove(\"visible\"); // Pause video playback of stream.\n\n\n    this._VideoCameraStream.play();\n\n    this._notifyOutputChanged();\n  };\n\n  ImageCapture.prototype.HidePhotoContainer = function (evt) {\n    var self = this;\n\n    self._VideoCameraStream.pause();\n\n    self._VideoCameraStream.src = \"\";\n    self._VideoCameraStream.srcObject = null;\n    self.HideUI();\n\n    self._notifyOutputChanged();\n  };\n\n  return ImageCapture;\n}();\n\nexports.ImageCapture = ImageCapture;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ImageCapture/index.ts?");

/***/ })

/******/ });
var ExtendXRM = ExtendXRM || {};
ExtendXRM.ImageCapture = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ImageCapture;
pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;